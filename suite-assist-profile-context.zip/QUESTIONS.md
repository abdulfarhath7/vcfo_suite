# QUESTIONS

Append-only. Judgement calls the docs don't cover. Don't block — pick the default,
record it, keep building.

## Q<n> — <short title>
- **Context:**
- **Default chosen:**
- **Alternative:**
- **Answer:** _(left blank for the human)_

---

## Q1 — Director identity across reorders
- **Context:** the extension's `mapping.js` targets MCA repeat panels by positional
  `instance`. Removing or reordering a director on pre-15 renumbers everyone, so a
  profile generated before the change puts one director's data against another's
  panel. The same hazard already exists for generated drafts.
- **Default chosen:** preserve `ProposedDirector.index` as array position, and also
  emit a stable `id` per director so a consumer can detect a reorder.
- **Alternative:** positional only, with a warning note in `notes`.
- **Answer:**

## Q2 — Sections Suite cannot supply
- **Context:** `agile`, `moa` and `aoa` largely have no home in `checklist_state`.
- **Default chosen:** emit them as `missing` with a reason, and treat the resulting
  list as the specification for a later Suite change.
- **Alternative:** add fields to existing steps now.
- **Answer:**
