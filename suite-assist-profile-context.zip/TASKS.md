# TASKS

Append-only. One entry per phase. Newest at the bottom.

## <date> — P<n> <phase name>
- Built:
- Files:
- Left out:
- Verification: `npm run typecheck && npm run test` pass / fail

---
